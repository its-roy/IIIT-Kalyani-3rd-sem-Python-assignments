a=input("Enter a string\n")
freq={}
for x in a:
 freq[x]=a.count(x)
for i in freq:
	if(freq[i]==1):
		print(i ,"is the first non-repeated")
		break
