a={}
n=int(input("Enter the size of dictionary\n"))
for i in range(n):
  a[i]=int(input("Enter the Values\n"))
print(a)
final = {}
for key,value in a.items():
    if value not in final.values():
        final[key] = value
print("Final dictionary is:\n")
print(final)
