a=input("Enter the words\n")
list=a.split()
freq={}
for i in list:
    if i in freq:
        freq[i]+=1
    else:
        freq[i]=1
print(freq)
print("The repeated words are:")
for i in freq:
    if freq[i] > 1:
        print(i)
