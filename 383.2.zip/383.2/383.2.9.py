a=input("Enter the words:\n")
list=a.split()
freq={}
for i in list:
    if i in freq:
        freq[i]+=1
    else:
        freq[i]=1
for i in freq:
        print('Frequency of ',i," is ",freq[i])
