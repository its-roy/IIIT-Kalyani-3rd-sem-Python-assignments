d={}
for x in range(1,21):
	d[x]=x*x
print(d)
sum=0
for x in range(1,21):
	a=int(d[x])
	sum=sum+a
print("Sum is ",sum)
m=max(d)
print("Max value is at key ",m,"with value",d[m])
m=min(d)
print("Min value is at key ",m,"with value",d[m])