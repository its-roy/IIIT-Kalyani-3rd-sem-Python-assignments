d={}
for x in range(1,21):
	d[x]=x*x
	print(d)