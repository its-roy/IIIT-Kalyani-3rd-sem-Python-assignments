a=input("Enter first string\n")
b=input("Enter second string\n")
c=len(a)
d=len(b)
e={}
f={}
count=0
if(c==d):
  for x in a:
     e[x]=a.count(x)
  for y in b:
     f[y]=b.count(y)
  if(e==f):
    print("The entered strings are ANAGRAM\n")
  else:
    print("The entered strings are not ANAGRAM\n")
else:
  print("The lengths of both strings are different.\n")

