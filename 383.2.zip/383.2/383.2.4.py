dict={}
n=int(input("Enter the number of term you want to add to the dictionary\n"))
x=1
while(x<=n):
	dict[x]=input("Enter the first term\n")
	x+=1
	print(dict)
	resdict={}
	for key,value in dict.items():
		if value not in resdict.values():
			print(resdict)