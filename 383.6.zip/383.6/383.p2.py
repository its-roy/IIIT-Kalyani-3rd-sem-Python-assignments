from xml.dom.minidom import parse
import xml.dom.minidom
DOMTree = xml.dom.minidom.parse("sample.xml")
collection = DOMTree.documentElement
movies = collection.getElementsByTagName("movie")
for movie in movies:
    print ("*****Movie*****")
    if movie.hasAttribute("title"):
      print ("Title: %s" % movie.getAttribute("title"))
    type = movie.getElementsByTagName('type')[0]
    print ("Type: %s" % type.childNodes[0].data)
    format = movie.getElementsByTagName('format')[0]
    print ("Format: %s" % format.childNodes[0].data)
    if(movie.getAttribute("title") != "Ishtar"):
        year = movie.getElementsByTagName('year')[0]
        print ("Year: %s" % year.childNodes[0].data)
    if movie.getAttribute("title")=="Golmaal":
        series = movie.getElementsByTagName("series")
        print ("*****Series*****")
        print ("No_of_link: %s" % series[0].getAttribute("no_of_link"))
        Link1 = collection.getElementsByTagName("Link1")
        print ("*****Link1*****")
        if Link1[0].hasAttribute("title"):
            print ("title: %s" % Link1[0].getAttribute("title"))
        Lyear = movie.getElementsByTagName('Lyear')[0]
        print ("Lyear: %s" % Lyear.childNodes[0].data)
        Link2 = collection.getElementsByTagName("Link2")
        print ("*****Link2*****")
        if Link2[0].hasAttribute("title"):
            print ("title: %s" % Link2[0].getAttribute("title"))
        Lyear = movie.getElementsByTagName('Lyear')[0]
        print ("Lyear: %s" % Lyear.childNodes[0].data)
    description = movie.getElementsByTagName('description')[0]
    print ("Description: %s" % description.childNodes[0].data)
