file=open("f1.txt","r")
file2=open("vowel.txt","w+")
file1=open("cons.txt","w+")
#print (file.read())
l=file.readlines()
for  y in l:
                if(y[0]=='a' or y[0]=='e' or y[0]=='i' or y[0]=='o' or y[0]=='u' or y[0]=='A' or y[0]=='E' or y[0]=='I' or y[0]=='O' or y[0]=='U'):
                    file2.write(y)
                else:
                    file1.write(y)
file.close()
file1.flush()
file2.flush()
file1.close()
file2.close()


