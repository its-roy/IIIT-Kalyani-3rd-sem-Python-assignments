file2=open("vowel.txt","a+")
file1=open("cons.txt","r")
s=file1.read()
file2.write(s)
file1.flush()
file2.flush()
file1.close()
file2.close()


