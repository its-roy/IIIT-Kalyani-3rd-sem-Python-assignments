import matplotlib.pyplot as plt

labels = 'Comedy', 'Action', 'Romance', 'Drama', 'Scifi'
size = [5, 8, 2, 3, 10]
colors = ['gold', 'green', 'lightcoral', 'lightskyblue','orangered']

plt.pie(size, labels=labels, colors=colors,
autopct='%1.1f%%', shadow=True, startangle=45)

plt.axis('equal')
plt.show()
