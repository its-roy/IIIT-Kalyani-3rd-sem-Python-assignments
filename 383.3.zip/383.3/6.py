import numpy as np
import matplotlib.pyplot as plt

Students = ('Jeff','Peter','John','Mary')  
y_pos = np.arange(len(Students))
practice = [60,75,55,80]
test=[70,90,55,95]
lege=['Practice Test','Test']
plt.bar(y_pos, practice,width=0.40, align='center', color='g')
plt.bar(y_pos+0.4, test,width=0.40, align='center', color='b')
plt.xticks(y_pos, Students)
plt.ylabel('Score')
plt.title('Test Score')
plt.legend(lege)

plt.show()
plt.barh(y_pos, practice,height=0.40, color='g')
plt.barh(y_pos+0.4, test,height=0.40, color='b')
plt.yticks(y_pos, Students)
plt.xlabel('Score')
plt.title('Test Score')
plt.legend(lege)

plt.show()
