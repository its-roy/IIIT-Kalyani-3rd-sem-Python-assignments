file=open("expr.txt","r+")
for i in range(0,3):
        l=file.read().splitlines()
        for x in range(0,len(l)):
                o=(l[x])
                a=eval(o)
                print(a)
