class files:
	def creating(self):
		fp1=open(str1,"w")
		fp2=open(str2,"w")
		fp1.write(str3)
		fp2.write(str4)
		fp1.close()
		fp2.close()
	def readfile(self,a,b):
		print("the data in file 1 is:")
		print(a.read())
		print("the data in file 2 is:")
		print(b.read())
	def writefile(self,a,b):
		b.write(a.read())
	def appendfile(self,a,b):
		a.write(b.read())
		
print("Enter full file name of first file(with extension):")
str1=input()
print("Enter full file name of first file(with extension):")
str2=input()
print("enter the first data:")
str3=input()
print("enter the second data:")
str4=input()
obj=files()
obj.creating()
print("1.Read the contents of first and second file.\n")
print("2.Copy contents of first file to second.")
print("\n3.Append contents of second file to first file")
while(True):
	print("Enter your choice:")
	opt=int(input())
	if(opt==1):
		fp1=open(str1,"r")
		fp2=open(str2,"r")
		obj.readfile(fp1,fp2)
		fp1.close()
		fp2.close()
	elif(opt==2):
		fp1=open(str1,"r")
		fp2=open(str2,"w")
		obj.writefile(fp1,fp2)
		fp2.close()
		fp2=open(str2,"r")
		print("Contents of second file is:")
		print(fp2.read())
		fp1.close()
		fp2.close()
	elif(opt==3):
		fp1=open(str1,"a")
		fp2=open(str2,"r")
		obj.appendfile(fp1,fp2)
		print("Appended Successfully")
		fp1.close()
		fp2.close()
	else:
		break
