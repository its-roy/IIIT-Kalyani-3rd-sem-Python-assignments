file=open("f1.txt","r")
file2=open("even.txt","w+")
file1=open("odd.txt","w+")
#print (file.read())
i=1
for l in file:
    if(i%2==0):
        file2.writelines(l)
        i+=1
    else:
        file1.writelines(l)
        i+=1
file.close()
file1.flush()
file2.flush()
file1.close()
file2.close()


