import re
text = "Write a Python program to remove words from a string of length between 1 and a given number."
shortword = re.compile(r'\W*\b\w{1,3}\b')
print(shortword.sub('', text))
