import re
text1 = '12. Write a Python program / to remove everything // except alphanumeric characters /// from a string.'
pattern = re.compile('[\W_]+')
print(pattern.sub('', text1))
