import re
regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'

def check(email):
    if (re.search(regex, email)):
        print("Valid Email")
    else:
        print("Invalid Email")

email = 'iiitkalyani.ac.in'
check(email)
email = "yahoo@gmail.com"
check(email)
email = "yahoo.in"
check(email)