import re
text = 'Write a Python program to find all three, four, five characters long words in a string.'
print(re.findall(r"\b\w{3,5}\b", text))
