import re
patterns = [ 'fox', 'dog', 'horse' ]
text = 'There is dog in my garden'
for pattern in patterns:
    print('Searching for "%s" in "%s" ->' % (pattern, text),)
    if re.search(pattern,  text):
        print('Matched')
    else:
        print('Not matched')
		