import re
def text_match(text):
        patterns = '\Bz\B'
        if re.search(patterns,  text):
                return 'matched'
        else:
                return('Not matched')

print(text_match("Write a Python program that matches a word containing 'z', not start or end of the word."))
print(text_match("Python Exercises."))
