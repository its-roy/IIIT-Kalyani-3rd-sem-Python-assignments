import re
text = "10. Write a Python program to separate and print the numbers and their position of a given string."

for m in re.finditer("\d+", text):
    print(m.group(0))
    print("Index position:", m.start())
	